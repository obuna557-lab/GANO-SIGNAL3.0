# GANO SIGNAL — tahrirlangan loyiha

Ushbu nusxada mavjud HTML interfeys, `ganoSignal_v3` mahalliy saqlash kaliti va 21 ta original mahsulot rasmi saqlangan.

## Ushbu tahrirdagi ishlar
- Android aniq budilnik ruxsati tekshiriladi; diagnostikada holati ko‘rsatiladi.
- Har bir signal uchun notification va tugma `PendingIntent` identifikatorlari alohida qilindi.
- Signal o‘chirilganda unga tegishli takroriy kechiktirish signali ham bekor qilinadi.
- Mahsulot miqdori: boshlang‘ich zaxira, dona/kapsula birligi va har qabul miqdori maydonlari qo‘shildi.
- “Ichdim” tasdiqlangandagina qoldiq kamayadi; bir kunning bir vaqt oralig‘i ikki marta hisoblanmaydi.
- Har mahsulot uchun foydalanuvchi belgilaydigan kurs davomiyligi (kun) qo‘shildi; 0 — cheklanmagan.
- Eski `localStorage` kaliti va mavjud mahsulot rasmlari/ma’lumotlari saqlanadi.

## Muhim cheklovlar
- Telefon butunlay o‘chirilganida ilova uni yoqa olmaydi. Telefon qayta yoqilgach, `BootReceiver` signallarni qayta rejalashtirishga urinadi.
- Ekran qulflangan yoki ilova yopiq holatdagi ishlash Android ruxsatlari va HONOR batareya boshqaruviga bog‘liq. Bir nechta real qurilmada sinash kerak.
- `minSdk 26`: Android 8.0 va undan yangi versiyalar. Android 7 va pastida ishlamaydi.
- Bu manba kodi; hozircha o‘rnatishga tayyor APK deb hisoblamang. Build va qurilmada sinov talab etiladi.
- Release imzolash kaliti xavfsizlik uchun arxivga kiritilmadi. Play Market uchun o‘zingiz xavfsiz saqlaydigan signing key kerak bo‘ladi.
- Mahsulot miqdori va qabul qaydlari faqat foydalanuvchi kiritgan ma’lumotlar asosida hisoblanadi; ilova dori dozasi tavsiya qilmaydi.
