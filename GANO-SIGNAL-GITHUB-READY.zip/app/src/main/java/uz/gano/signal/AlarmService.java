package uz.gano.signal;
import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.media.*;import android.net.Uri;import android.os.*;
public class AlarmService extends Service{
 static volatile boolean ringing=false;
 MediaPlayer mp;Vibrator vb;PowerManager.WakeLock wl;Handler h=new Handler(Looper.getMainLooper());
 public IBinder onBind(Intent i){return null;}
 public int onStartCommand(Intent in,int f,int sid){
  if(in==null){stopSelf();return START_NOT_STICKY;}
  String act=in.getAction();int id=in.getIntExtra("id",0);
  if("TAKEN".equals(act)){Alarm.addRing(this,id);end();return START_NOT_STICKY;}
  if("SNOOZE".equals(act)){Alarm.set(this,id,System.currentTimeMillis()+5*60000,true);end();return START_NOT_STICKY;}
  if("STOP".equals(act)){end();return START_NOT_STICKY;}
  String name=in.getStringExtra("name");
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
  nm.createNotificationChannel(new NotificationChannel("ring","Budilnik",NotificationManager.IMPORTANCE_HIGH));
  int fl=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
  PendingIntent full=PendingIntent.getActivity(this,100+id,new Intent(this,AlarmActivity.class).putExtra("id",id).putExtra("name",name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),fl);
  PendingIntent ok=PendingIntent.getService(this,200+id,new Intent(this,AlarmService.class).setAction("TAKEN").putExtra("id",id),fl);
  PendingIntent sn=PendingIntent.getService(this,300+id,new Intent(this,AlarmService.class).setAction("SNOOZE").putExtra("id",id),fl);
  Notification n=new Notification.Builder(this,"ring").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(name).setContentText("Qabul vaqti!")
   .setCategory(Notification.CATEGORY_ALARM).setOngoing(true).setFullScreenIntent(full,true).setContentIntent(full)
   .addAction(new Notification.Action.Builder(null,"Ichdim",ok).build()).addAction(new Notification.Action.Builder(null,"5 daqiqadan keyin",sn).build()).build();
  startForeground(100+id,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
  ringing=true;
  PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
  if(wl==null){wl=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"gano:alarm");wl.acquire(6*60000L);}
  int[] types={RingtoneManager.TYPE_ALARM,RingtoneManager.TYPE_RINGTONE,RingtoneManager.TYPE_NOTIFICATION};
  for(int ty:types){try{Uri u=RingtoneManager.getDefaultUri(ty);if(mp!=null)mp.release();mp=new MediaPlayer();mp.setDataSource(this,u);
   mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
   mp.setLooping(true);mp.prepare();mp.start();break;}catch(Exception e){Alarm.p(this).edit().putString("err","sound: "+e).apply();}}
  vb=(Vibrator)getSystemService(VIBRATOR_SERVICE);vb.vibrate(VibrationEffect.createWaveform(new long[]{0,500,300,500,300},0));
  startActivity(new Intent(this,AlarmActivity.class).putExtra("id",id).putExtra("name",name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  h.removeCallbacksAndMessages(null);
  h.postDelayed(this::end,Alarm.p(this).getInt("ringMin",4)*60000L);
  return START_NOT_STICKY;}
 void end(){ringing=false;h.removeCallbacksAndMessages(null);
  try{if(mp!=null){mp.stop();mp.release();mp=null;}}catch(Exception e){}
  if(vb!=null)vb.cancel();if(wl!=null&&wl.isHeld())wl.release();wl=null;
  stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
 public void onDestroy(){ringing=false;super.onDestroy();}
}
