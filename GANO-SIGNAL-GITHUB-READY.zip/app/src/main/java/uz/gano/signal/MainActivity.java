package uz.gano.signal;
import android.Manifest;import android.app.*;import android.content.*;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.webkit.*;import org.json.*;import java.text.SimpleDateFormat;import java.util.*;
public class MainActivity extends Activity{
 WebView wv;
 protected void onCreate(Bundle b){super.onCreate(b);
  try{createDeviceProtectedStorageContext().moveSharedPreferencesFrom(this,"gano");}catch(Exception e){}
  if(Build.VERSION.SDK_INT>=33)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},1);
  wv=new WebView(this);WebSettings s=wv.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
  wv.addJavascriptInterface(new Bridge(),"Android");
  wv.setWebViewClient(new WebViewClient(){public void onPageFinished(WebView v,String u){flush();}});
  wv.loadUrl("file:///android_asset/index.html");setContentView(wv);Alarm.checkMissed(this);Alarm.rescheduleAll(this);
  try{startForegroundService(new Intent(this,KeepService.class));}catch(Exception e){Alarm.log(this,"xizmat: "+e.getClass().getSimpleName());}}
 protected void onResume(){super.onResume();flush();}
 void flush(){String r=Alarm.p(this).getString("rings","[]");if("[]".equals(r))return;Alarm.p(this).edit().putString("rings","[]").apply();
  wv.evaluateJavascript("window.nativeRings&&nativeRings("+r+")",null);}
 class Bridge{
  @JavascriptInterface public void schedule(int id,int h,int m,String n,int i){Alarm.schedule(MainActivity.this,id,h,m,n,i);}
  @JavascriptInterface public void cancel(int id){Alarm.cancel(MainActivity.this,id);}
  @JavascriptInterface public void setRing(int m){Alarm.p(MainActivity.this).edit().putInt("ringMin",m).apply();}
  @JavascriptInterface public void test(){try{startForegroundService(new Intent(MainActivity.this,AlarmService.class).putExtra("id",99).putExtra("name","Sinov"));}catch(Exception e){}}
  @JavascriptInterface public void perms(){runOnUiThread(()->{
   PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
   if(!pm.isIgnoringBatteryOptimizations(getPackageName()))startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName())));
   else if(Build.VERSION.SDK_INT>=31&&!((AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms())startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));
   else if(Build.VERSION.SDK_INT>=34&&!((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).canUseFullScreenIntent())startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())));
   else startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));});}
  @JavascriptInterface public String diag(){try{
   SharedPreferences p=Alarm.p(MainActivity.this);NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
   PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);SimpleDateFormat f=new SimpleDateFormat("dd.MM HH:mm",Locale.US);
   JSONObject o=new JSONObject();o.put("notif",nm.areNotificationsEnabled());o.put("full",Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent());o.put("exact",Build.VERSION.SDK_INT<31||((AlarmManager)getSystemService(ALARM_SERVICE)).canScheduleExactAlarms());
   o.put("batt",pm.isIgnoringBatteryOptimizations(getPackageName()));o.put("err",p.getString("err",""));o.put("model",Build.MANUFACTURER+" "+Build.MODEL+" A"+Build.VERSION.SDK_INT);
   JSONArray ar=new JSONArray();for(int id=0;id<42;id++){String s=p.getString("a"+id,null);if(s==null)continue;String[] a=s.split("\\|",4);
    long nx=p.getLong("next"+id,0),ls=p.getLong("last"+id,0);
    ar.put(new JSONObject().put("n",a[2]+" ("+(id%2+1)+")").put("next",nx==0?"-":f.format(new Date(nx))).put("last",ls==0?"hali chalinmagan":f.format(new Date(ls))).put("miss",nx>0&&nx<System.currentTimeMillis()-60000&&ls<nx));}
   o.put("alarms",ar);o.put("log",p.getString("log",""));return o.toString();}catch(Exception e){return "{}";}}
 }
}
