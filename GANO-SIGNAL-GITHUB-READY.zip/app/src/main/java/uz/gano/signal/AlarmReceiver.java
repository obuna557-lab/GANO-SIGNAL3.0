package uz.gano.signal;
import android.content.*;
public class AlarmReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent in){
  int id=in.getIntExtra("id",0);boolean sn=in.getBooleanExtra("snooze",false);
  Alarm.log(c,"signal keldi id="+id+(sn?" (keyinroq)":""));
  String s=Alarm.p(c).getString("a"+id,null);if(s==null)return;
  String[] a=s.split("\\|",4);
  if(!sn)Alarm.set(c,id,Alarm.nextTime(Integer.parseInt(a[0]),Integer.parseInt(a[1])),false); // ertangi kunga darhol
  Alarm.p(c).edit().putLong("last"+id,System.currentTimeMillis()).apply();
  try{c.startForegroundService(new Intent(c,AlarmService.class).putExtra("id",id).putExtra("name",a[2]));}
  catch(Exception e){Alarm.p(c).edit().putString("err","service: "+e).apply();}
 }}
